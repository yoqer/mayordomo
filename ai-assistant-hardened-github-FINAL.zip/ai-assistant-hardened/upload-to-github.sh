#!/bin/bash
# Script para subir AI Assistant Hardened a GitHub
# Ejecuta este script después de descomprimir el ZIP

set -e

echo "🚀 AI Assistant Hardened - GitHub Upload Script"
echo "================================================"
echo ""

# Verificar que estamos en el directorio correcto
if [ ! -f "docker-compose.yaml" ]; then
    echo "❌ Error: No estás en el directorio correcto"
    echo "   Asegúrate de ejecutar este script desde ai-assistant-hardened/"
    exit 1
fi

# Solicitar nombre de usuario de GitHub
echo "📝 Introduce tu nombre de usuario de GitHub:"
read -r GITHUB_USER

if [ -z "$GITHUB_USER" ]; then
    echo "❌ Error: El nombre de usuario no puede estar vacío"
    exit 1
fi

# Nombre del repositorio
REPO_NAME="ai-assistant-hardened"

echo ""
echo "📋 Configuración:"
echo "   Usuario: $GITHUB_USER"
echo "   Repositorio: $REPO_NAME"
echo ""

# Verificar si gh CLI está instalado
if command -v gh &> /dev/null; then
    echo "✅ GitHub CLI (gh) detectado"
    echo ""
    echo "🔐 Verificando autenticación..."
    
    if gh auth status &> /dev/null; then
        echo "✅ Ya estás autenticado en GitHub"
    else
        echo "🔑 Iniciando autenticación en GitHub..."
        gh auth login
    fi
    
    echo ""
    echo "📦 Creando repositorio en GitHub..."
    echo "   (Esto puede tardar unos segundos...)"
    
    # Crear repositorio usando gh CLI
    gh repo create "$REPO_NAME" \
        --public \
        --source=. \
        --description "🔒 Production-ready hardened AI chat assistant with Docker security best practices" \
        --push
    
    if [ $? -eq 0 ]; then
        echo ""
        echo "✅ ¡Repositorio creado y código subido exitosamente!"
        echo ""
        echo "🌐 Abriendo repositorio en el navegador..."
        gh repo view --web
        
        echo ""
        echo "🎉 ¡TODO LISTO!"
        echo ""
        echo "📍 Tu repositorio está en:"
        echo "   https://github.com/$GITHUB_USER/$REPO_NAME"
        echo ""
        echo "🔧 Próximos pasos recomendados:"
        echo "   1. Añade topics en Settings → About"
        echo "   2. Habilita Dependabot en Settings → Security"
        echo "   3. Configura secrets/*.txt para usar el proyecto"
    else
        echo ""
        echo "❌ Error al crear el repositorio"
        echo "   Revisa los errores arriba"
        exit 1
    fi
    
else
    echo "⚠️  GitHub CLI (gh) no está instalado"
    echo ""
    echo "📝 Método alternativo (usando Git):"
    echo ""
    echo "1️⃣  Primero, crea un repositorio en GitHub:"
    echo "    👉 https://github.com/new"
    echo "    - Nombre: $REPO_NAME"
    echo "    - Descripción: 🔒 Production-ready hardened AI chat assistant"
    echo "    - NO inicializar con README, .gitignore o LICENSE"
    echo ""
    echo "2️⃣  Luego ejecuta estos comandos:"
    echo ""
    echo "    git remote add origin https://github.com/$GITHUB_USER/$REPO_NAME.git"
    echo "    git push -u origin main"
    echo ""
    echo "3️⃣  Si GitHub te pide autenticación:"
    echo "    - Usa Personal Access Token (recomendado)"
    echo "    - O instala GitHub CLI: https://cli.github.com/"
    echo ""
    
    # Preguntar si quiere continuar manualmente
    echo "¿Quieres que añada el remote ahora? (s/n)"
    read -r CONTINUE
    
    if [ "$CONTINUE" = "s" ] || [ "$CONTINUE" = "S" ]; then
        echo ""
        echo "🔗 Añadiendo remote..."
        git remote add origin "https://github.com/$GITHUB_USER/$REPO_NAME.git"
        
        echo ""
        echo "✅ Remote añadido"
        echo ""
        echo "📤 Ahora ejecuta: git push -u origin main"
    fi
fi

echo ""
echo "📚 Documentación completa en GITHUB_UPLOAD.md"
echo ""
