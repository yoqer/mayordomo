# 🔒 AI_Assistant — Hardened Production-Ready Local Deployment

[![Docker](https://img.shields.io/badge/Docker-Ready-2496ED?logo=docker&logoColor=white)](https://www.docker.com/)
[![Security](https://img.shields.io/badge/Security-Hardened-green)](./SECURITY_CHANGES.md)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](./LICENSE)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.30+-FF4B4B?logo=streamlit&logoColor=white)](https://streamlit.io/)

**Versión endurecida** del proyecto [yoqer/AI_Assistant](https://github.com/yoqer/AI_Assistant) optimizada para despliegue local seguro tipo producción.

![AI Assistant Demo](https://img.shields.io/badge/Status-Production%20Ready-success)

---

## ✨ Características principales

- ✅ Chat con memoria (LangChain + Streamlit)
- ✅ Modelo local (Docker Model Runner) + remoto (OpenRouter/Grok/custom)
- ✅ **Hardening completo** (no-root, read-only, secrets externos)
- ✅ Solo accesible desde localhost por defecto
- ✅ Límites de recursos (2GB RAM, 2 CPUs)
- ✅ Healthcheck funcional
- ✅ Logging con rotación automática

---

## 🚀 Quick Start (3 pasos)

### 1️⃣ Configurar secrets
```bash
# Edita y añade tu API key
echo "TU_API_KEY_AQUI" > secrets/openrouter_api_key.txt
```

### 2️⃣ Crear .env
```bash
cp .env.example .env
# Edita .env si quieres cambiar modelos/URLs
```

### 3️⃣ Levantar
```bash
docker compose up --build
```

Abrir: **http://localhost:8501**

---

## 📚 Documentación completa

- **[ReadmeUse.md](ReadmeUse.md)** — Guía de uso paso a paso
- **[ReadmeREPO.md](ReadmeREPO.md)** — Documentación técnica del hardening
- **[SECURITY_CHANGES.md](SECURITY_CHANGES.md)** — Registro detallado de cambios de seguridad

---

## 🔐 Seguridad

Este proyecto mitiga:
- CVE-2025-62725 (Docker Compose path traversal)
- CVE-2025-9074 (Docker Desktop container escape)
- Exposición de secrets en env vars
- Escalada de privilegios
- Acceso remoto no autorizado

**Requiere:**
- Docker Compose v2.40.2+
- Docker Desktop v4.44.3+

---

## 🛠️ Modos de operación

### Seguro (default)
```bash
docker compose up --build
```

### Dev (con bind mount)
```bash
docker compose --profile dev -f docker-compose.yaml -f docker-compose.dev.yaml up --build
```

---

## 📁 Estructura

```
.
├── docker-compose.yaml          # Compose endurecido
├── docker-compose.dev.yaml      # Override para dev
├── Dockerfile                   # Imagen no-root
├── app.py                       # App Streamlit
├── requirements.txt             # Dependencias
├── .env.example                 # Plantilla de config
├── .streamlit/config.toml       # Config Streamlit
├── secrets/                     # API keys (NO comitear)
├── model_selector.html          # Selector de modelos
├── ReadmeUse.md                 # Guía de uso
├── ReadmeREPO.md                # Doc técnica
└── SECURITY_CHANGES.md          # Registro de cambios
```

---

## 🤝 Créditos

Basado en [yoqer/AI_Assistant](https://github.com/yoqer/AI_Assistant) con mejoras de seguridad aplicadas.

---

## 🤝 Contribuir

Lee [CONTRIBUTING.md](CONTRIBUTING.md) para detalles sobre cómo contribuir.

## 📝 Changelog

Ver [CHANGELOG.md](CHANGELOG.md) para historial de cambios.

## 📝 Licencia

MIT — Ver [LICENSE](LICENSE) para detalles.

## 🙏 Reconocimientos

- Basado en [yoqer/AI_Assistant](https://github.com/yoqer/AI_Assistant)
- Inspirado en [Docker Security Best Practices](https://docs.docker.com/develop/security-best-practices/)
- [CIS Docker Benchmark](https://www.cisecurity.org/benchmark/docker)

## 📧 Contacto

Si encuentras problemas de seguridad, por favor repórtalos de manera responsable abriendo un issue privado.

---

⭐ Si este proyecto te resulta útil, considera darle una estrella en GitHub
