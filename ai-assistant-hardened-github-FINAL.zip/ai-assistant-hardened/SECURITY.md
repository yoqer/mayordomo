# Security Policy

## Versiones soportadas

| Versión | Soportada          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reportar una vulnerabilidad

Si descubres una vulnerabilidad de seguridad, por favor **NO** abras un issue público.

En su lugar:

1. **Contacta de forma privada** abriendo un Security Advisory en GitHub
2. Incluye una descripción detallada del problema
3. Proporciona pasos para reproducir (si es aplicable)
4. Indica el impacto potencial
5. Si tienes un parche sugerido, inclúyelo

## Respuesta esperada

- **Confirmación inicial:** Dentro de 48 horas
- **Evaluación completa:** Dentro de 7 días
- **Parche (si procede):** Según severidad (crítico: 24-48h, alto: 7 días, medio/bajo: 30 días)

## Ámbito de seguridad

### Dentro del ámbito
- Vulnerabilidades en la configuración de Docker/Docker Compose
- Exposición de secrets/credenciales
- Escalada de privilegios dentro del contenedor
- Bypass de hardening implementado
- Vulnerabilidades en dependencias Python

### Fuera del ámbito
- Vulnerabilidades en Docker Engine/Desktop (reportar a Docker Inc.)
- Vulnerabilidades en Streamlit upstream (reportar a Streamlit)
- Ataques que requieren acceso físico al host
- Social engineering

## Mejores prácticas recomendadas

1. **Actualiza regularmente:**
   - Docker Desktop a v4.44.3+
   - Docker Compose a v2.40.2+
   
2. **Protege tus secrets:**
   - Nunca comitees archivos `secrets/*.txt`
   - Rota API keys periódicamente
   - Usa permisos 600 para archivos de secrets

3. **Monitorea:**
   - Logs del contenedor
   - Estado del healthcheck
   - Uso de recursos

4. **Red:**
   - Mantén puerto localhost-only en producción
   - Si expones a LAN, usa firewall/VPN

## Dependencias conocidas

Este proyecto depende de:
- `langchain_openai` - Cliente OpenAI/compatible
- `streamlit` - Framework web
- Base image `python:3.12-slim`

Ejecuta `docker scout` para escanear vulnerabilidades:
```bash
docker scout cves ai-assistant-hardened-ai-app
```

## Referencias

- CVE-2025-62725: https://nvd.nist.gov/vuln/detail/CVE-2025-62725
- CVE-2025-9074: https://docs.docker.com/security/security-announcements/
- Docker Security: https://docs.docker.com/engine/security/
- CIS Docker Benchmark: https://www.cisecurity.org/benchmark/docker
