# Contribuir a AI_Assistant Hardened

¡Gracias por tu interés en contribuir! 🎉

## Cómo contribuir

### Reportar bugs
- Abre un issue describiendo el problema
- Incluye pasos para reproducir
- Especifica tu versión de Docker/Docker Compose

### Sugerir mejoras
- Abre un issue con la etiqueta "enhancement"
- Describe claramente la funcionalidad propuesta
- Explica el caso de uso

### Pull Requests

1. Fork el repositorio
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

### Estándares de código

- Mantén el estilo de código consistente
- Documenta funciones nuevas
- Actualiza README si es necesario
- Verifica que el proyecto funcione con `docker compose up`

### Checklist de seguridad para PRs

- [ ] No expone secrets/API keys
- [ ] Mantiene principio de mínimo privilegio
- [ ] No degrada configuración de hardening
- [ ] Documenta cambios de seguridad en SECURITY_CHANGES.md

## Código de conducta

- Sé respetuoso y constructivo
- Enfócate en el código, no en las personas
- Acepta feedback de manera profesional

¡Gracias por hacer este proyecto mejor! 🚀
