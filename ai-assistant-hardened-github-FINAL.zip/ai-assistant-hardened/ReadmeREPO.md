# ReadmeREPO — Documentación técnica del endurecimiento

Este documento explica **por qué y cómo** se endureció el proyecto [yoqer/AI_Assistant](https://github.com/yoqer/AI_Assistant) para despliegue local seguro tipo producción.

---

## 📊 Comparativa: Original vs Endurecido

| Aspecto | Original | Endurecido |
|---------|----------|------------|
| **Bind mount** | Siempre (`./:/app`) | Solo en modo dev |
| **Usuario** | root | no-root (uid 10001) |
| **Filesystem** | read-write | read-only + tmpfs |
| **Secrets** | Variables env | Archivos externos |
| **Puerto** | 0.0.0.0:8501 | 127.0.0.1:8501 |
| **Capabilities** | Todas | Ninguna (ALL drop) |
| **Límites recursos** | Sin límites | 2GB RAM, 2 CPUs |
| **Logging** | Sin rotación | 10MB x 3 archivos |
| **Healthcheck** | curl a :8081 | wget a /?healthz=1 |
| **Restart policy** | No | unless-stopped |

---

## 🔐 Vulnerabilidades mitigadas

### CVE-2025-62725 (Docker Compose Path Traversal)
- **CVSS:** 8.9
- **Mitigación:** Actualizar Docker Compose a v2.40.2+
- **Referencia:** https://nvd.nist.gov/vuln/detail/CVE-2025-62725

### CVE-2025-9074 (Docker Desktop Container Escape)
- **CVSS:** 9.3
- **Mitigación:** Actualizar Docker Desktop a v4.44.3+
- **Referencia:** https://docs.docker.com/security/security-announcements/

### CVE-2025-12735 (Docker Hardened Images)
- **Nota:** Este proyecto no usa Docker Hardened Images actualmente
- **Recomendación futura:** Migrar base image a hardened variant
- **Referencia:** https://www.docker.com/products/hardened-images/

---

## 🛡️ Medidas de hardening aplicadas

### 1) Usuario no-root
```dockerfile
RUN useradd -m -u 10001 -s /usr/sbin/nologin nonroot
USER nonroot
```

**Beneficio:** Si un atacante compromete la app, no tiene privilegios de root.

### 2) Filesystem read-only
```yaml
read_only: true
tmpfs:
  - /tmp
  - /home/nonroot
  - /app/.streamlit
  - /app/.cache
```

**Beneficio:** Impide que malware escriba en el filesystem (excepto tmpfs que se borra).

### 3) Capabilities drop
```yaml
cap_drop:
  - ALL
```

**Beneficio:** Elimina capacidades del kernel innecesarias (net_bind, sys_admin, etc).

### 4) No new privileges
```yaml
security_opt:
  - no-new-privileges:true
```

**Beneficio:** Impide escalada de privilegios vía setuid/setgid.

### 5) Secrets externos
```yaml
secrets:
  openrouter_api_key:
    file: ./secrets/openrouter_api_key.txt
```

**Beneficio:** Las claves no quedan en variables de entorno (menos exposure en logs/procesos).

### 6) Puerto localhost-only
```yaml
ports:
  - "127.0.0.1:8501:8501"
```

**Beneficio:** No accesible desde LAN/Internet accidentalmente.

### 7) Límites de recursos
```yaml
mem_limit: 2g
cpus: "2.0"
pids_limit: 256
```

**Beneficio:** Protección contra fork bombs y memory exhaustion.

### 8) Logging con rotación
```yaml
logging:
  driver: "json-file"
  options:
    max-size: "10m"
    max-file: "3"
```

**Beneficio:** Evita que logs llenen el disco.

### 9) Init process
```yaml
init: true
```

**Beneficio:** Maneja señales correctamente y evita zombies.

### 10) Restart policy
```yaml
restart: unless-stopped
```

**Beneficio:** Recuperación automática tras fallos/reinicios del host.

---

## 🧪 Healthcheck mejorado

### Original (no funcional)
```yaml
test: ["CMD", "curl", "-f", "http://localhost:8081/health"]
```

**Problema:** 
- curl no incluido en imagen slim
- Puerto 8081 no existe en Streamlit (usa 8501)

### Mejorado (funcional)
```yaml
test: ["CMD", "wget", "-qO-", "http://localhost:8501/?healthz=1"]
interval: 30s
timeout: 5s
retries: 5
start_period: 10s
```

**Mejoras:**
- wget instalado en Dockerfile
- Puerto correcto (8501)
- Endpoint dedicado (?healthz=1 en app.py)
- start_period para dar tiempo al arranque

---

## 📁 Estructura de archivos

### docker-compose.yaml (base seguro)
Configuración production-ready sin bind mounts.

### docker-compose.dev.yaml (override dev)
Solo se activa con `--profile dev`. Añade bind mount y desactiva read-only.

### Dockerfile (multi-stage posible)
- Instala wget para healthcheck
- Crea usuario nonroot
- Copy optimizado para cache

### app.py (con secrets + healthz)
- Lee secrets desde `/run/secrets/*`
- Endpoint `/?healthz=1` para healthcheck
- Manejo de errores mejorado

### .streamlit/config.toml
- XSRF protection habilitado
- CORS deshabilitado
- headless mode
- Tema oscuro

---

## 🔄 Workflow recomendado

### Desarrollo local
```bash
docker compose --profile dev -f docker-compose.yaml -f docker-compose.dev.yaml up
```
- Bind mount activo
- Hot reload
- Puerto 0.0.0.0 (LAN)

### Testing/Staging
```bash
docker compose up --build
```
- Sin bind mount
- Solo localhost
- Configuración hardened

### Producción (servidor público)
Añadir:
- Reverse proxy (Caddy/Traefik) con TLS
- Autenticación
- Rate limiting
- Monitoring

---

## 🚨 Limitaciones conocidas

1. **Docker Model Runner solo local:** No funciona en cloud sin Docker Desktop
2. **Streamlit healthcheck:** No es un endpoint HTTP real (workaround con query params)
3. **Secrets en archivos:** Para K8s sería mejor usar secrets nativos
4. **No TLS nativo:** Requiere reverse proxy para HTTPS

---

## 📚 Referencias

- Docker Compose security: https://docs.docker.com/compose/compose-file/deploy/#security_opt
- Docker secrets: https://docs.docker.com/engine/swarm/secrets/
- CIS Docker Benchmark: https://www.cisecurity.org/benchmark/docker
- OWASP Container Security: https://cheatsheetseries.owasp.org/cheatsheets/Docker_Security_Cheat_Sheet.html

---

## 🔮 Mejoras futuras sugeridas

1. **Multi-stage build** para imagen más pequeña
2. **Distroless base image** (google/distroless)
3. **Scan de vulnerabilidades** (Docker Scout / Trivy)
4. **SBOM generation** (Syft)
5. **Network policies** si se deploya en Swarm/K8s
6. **Secrets rotation** automatizado
7. **Audit logging** (syslog/fluentd)
