# Changelog

Todos los cambios notables en este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/),
y este proyecto adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.0] - 2026-01-31

### Añadido
- Versión inicial del proyecto endurecido
- Hardening completo de seguridad (usuario no-root, read-only filesystem, secrets externos)
- Soporte multi-proveedor (OpenRouter, Grok, Custom OpenAI-compatible)
- Selector de modelos HTML (model_selector.html)
- Documentación completa (ReadmeUse, ReadmeREPO, SECURITY_CHANGES)
- Healthcheck funcional con endpoint dedicado
- Configuración Streamlit endurecida
- Límites de recursos (2GB RAM, 2 CPUs)
- Logging con rotación automática
- Modo desarrollo con perfiles Docker Compose
- Archivo .gitignore para proteger secrets
- Plantillas de secrets en secrets/*.txt

### Seguridad
- Mitigación de CVE-2025-62725 (Docker Compose path traversal) mediante actualización de runtime
- Mitigación de CVE-2025-9074 (Docker Desktop container escape) mediante actualización de runtime
- Puerto solo localhost (127.0.0.1:8501)
- Capabilities drop ALL
- No-new-privileges habilitado
- Filesystem read-only con tmpfs
- Secrets externos (no en env vars)

### Documentación
- README.md principal con quick start
- ReadmeUse.md con guía completa de instalación
- ReadmeREPO.md con documentación técnica del hardening
- SECURITY_CHANGES.md con registro detallado de cambios
- CONTRIBUTING.md con guías para contribuir
- LICENSE (MIT)

## [Unreleased]

### Por hacer
- Migrar a Docker Hardened Images
- Implementar multi-stage build para imagen más pequeña
- Añadir soporte para Kubernetes/Swarm
- Integrar Docker Scout para escaneo de vulnerabilidades
- Añadir tests automatizados
- Implementar rotation automática de secrets
