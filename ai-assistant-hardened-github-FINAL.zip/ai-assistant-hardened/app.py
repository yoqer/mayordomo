from langchain_openai import ChatOpenAI
import streamlit as st
import os

def read_secret(path: str) -> str:
    """Lee un secret desde /run/secrets (Docker) o retorna cadena vacía"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""

# ------------------------------
# HEALTHZ (para docker healthcheck)
# Acceso: http://localhost:8501/?healthz=1
# ------------------------------
if st.query_params.get("healthz") == "1":
    st.write("ok")
    st.stop()

# ------------------------------
# ENV (no secret)
# ------------------------------
LOCAL_MODEL_NAME = os.environ.get("LOCAL_MODEL_NAME", "ai/qwen2.5")
REMOTE_MODEL_NAME = os.environ.get("REMOTE_MODEL_NAME", "qwen/qwen3-30b-a3b")

LOCAL_BASE_URL = os.environ.get("LOCAL_BASE_URL", "http://model-runner.docker.internal/engines/llama.cpp/v1")
REMOTE_BASE_URL = os.environ.get("REMOTE_BASE_URL", "https://openrouter.ai/api/v1")

# ------------------------------
# SECRETS (preferidos)
# ------------------------------
OPENROUTER_API_KEY = read_secret("/run/secrets/openrouter_api_key") or os.environ.get("OPENROUTER_API_KEY", "")
REMOTE_API_KEY = read_secret("/run/secrets/remote_api_key") or os.environ.get("REMOTE_API_KEY", "")
GROK_API_KEY = read_secret("/run/secrets/grok_api_key") or os.environ.get("GROK_API_KEY", "")

# ------------------------------
# LLMs
# ------------------------------
local_llm = ChatOpenAI(
    model=LOCAL_MODEL_NAME,
    api_key="nope",
    base_url=LOCAL_BASE_URL
)

# Cloud key: prioridad OpenRouter > Remote > Grok
cloud_key = OPENROUTER_API_KEY or REMOTE_API_KEY or GROK_API_KEY
cloud_llm = None
if cloud_key:
    cloud_llm = ChatOpenAI(model=REMOTE_MODEL_NAME, api_key=cloud_key, base_url=REMOTE_BASE_URL)

# ------------------------------
# UI
# ------------------------------
st.set_page_config(page_title="AI Assistant", layout="centered")

st.title("Talk to me...")

with st.sidebar:
    st.header("Configuración")
    st.caption(f"**Modelo local:** {LOCAL_MODEL_NAME}")
    if cloud_llm:
        st.caption(f"**Modelo remoto:** {REMOTE_MODEL_NAME}")
    else:
        st.warning("Modelo remoto no disponible (falta API key)")
    
    st.divider()
    st.caption("🔒 Modo seguro activado")
    st.caption("Puerto: localhost:8501")

think_harder = st.checkbox("Think harder (usar modelo remoto)...", value=False)

st.session_state.setdefault("messages", [])

for msg in st.session_state["messages"]:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

prompt = st.chat_input("Escribe tu mensaje...")

if prompt:
    st.session_state["messages"].append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.write(prompt)

    # Contexto con saltos
    context = ""
    for msg in st.session_state["messages"]:
        context += f'{msg["role"]}: {msg["content"]}\n'

    if think_harder:
        if cloud_llm is None:
            st.error("Modelo remoto seleccionado pero no hay API key en secrets/env.")
            st.stop()
        llm = cloud_llm
    else:
        llm = local_llm

    try:
        response = llm.invoke(context)
        st.session_state["messages"].append({"role": "assistant", "content": response.content})
        with st.chat_message("assistant"):
            st.write(response.content)
    except Exception as e:
        with st.chat_message("assistant"):
            st.error(f"Error al invocar el modelo: {e}")
