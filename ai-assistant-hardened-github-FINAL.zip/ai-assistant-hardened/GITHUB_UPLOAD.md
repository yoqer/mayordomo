# 🚀 Guía para subir a GitHub

Este repositorio está listo para ser publicado en GitHub. Sigue estos pasos:

## Opción 1: Crear repositorio nuevo en GitHub (Recomendado)

### Paso 1: Crear repositorio en GitHub
1. Ve a https://github.com/new
2. Nombre del repositorio: `ai-assistant-hardened` (o el que prefieras)
3. Descripción: `🔒 Production-ready hardened AI chat assistant with Docker security best practices`
4. **NO** inicialices con README, .gitignore o LICENSE (ya los tenemos)
5. Selecciona visibilidad: **Public** o **Private**
6. Click en "Create repository"

### Paso 2: Conectar y subir desde tu máquina local
```bash
# Descomprimir el proyecto (si usas el ZIP)
unzip ai-assistant-hardened-github.zip
cd ai-assistant-hardened

# Verificar que el repositorio Git está inicializado
git status

# Añadir remote (reemplaza TU_USUARIO con tu usuario de GitHub)
git remote add origin https://github.com/TU_USUARIO/ai-assistant-hardened.git

# Push al repositorio (primera vez)
git push -u origin main
```

Si GitHub te pide autenticación, usa:
- **Personal Access Token** (recomendado): Settings → Developer settings → Personal access tokens
- O **GitHub CLI**: `gh auth login`

### Paso 3: Configurar GitHub (opcional pero recomendado)

#### Activar Security Features
1. Ve a Settings → Security → Enable "Vulnerability alerts"
2. Enable "Dependabot alerts"
3. Enable "Dependabot security updates"

#### Añadir Topics (etiquetas)
Settings → Add topics:
- `docker`
- `security`
- `streamlit`
- `langchain`
- `hardened`
- `ai-assistant`
- `production-ready`

#### Crear GitHub Actions (CI/CD opcional)
Considera añadir workflows para:
- Docker build test
- Security scan (Docker Scout / Trivy)
- Linting

---

## Opción 2: Fork desde repositorio existente

Si ya existe un repositorio `yoqer/AI_Assistant`:

```bash
# Clonar tu fork
git clone https://github.com/TU_USUARIO/AI_Assistant.git
cd AI_Assistant

# Crear rama para hardening
git checkout -b hardened-production

# Copiar archivos del proyecto endurecido aquí
cp -r ../ai-assistant-hardened/* .

# Commit y push
git add .
git commit -m "Add hardened production configuration"
git push origin hardened-production

# Luego crear Pull Request en GitHub
```

---

## Opción 3: Subir usando GitHub CLI

Si tienes `gh` instalado:

```bash
cd ai-assistant-hardened

# Crear repositorio directamente
gh repo create ai-assistant-hardened --public --source=. --remote=origin

# Push
git push -u origin main

# Abrir en navegador
gh repo view --web
```

---

## ✅ Verificación post-upload

Después de subir, verifica:

1. **README.md se renderiza correctamente** en la página principal
2. **No hay secrets expuestos** (verifica que secrets/*.txt NO están)
3. **Los badges funcionan** (Docker, Security, License)
4. **Las issues y PRs están habilitadas** (Settings → Features)
5. **License se detecta** (debería aparecer en "About" sidebar)

---

## 🎯 Promoción del repositorio

Una vez subido, considera:

1. **Añadir a awesome-lists:**
   - awesome-docker
   - awesome-security
   - awesome-streamlit

2. **Social media:**
   - Twitter/X: hashtags #Docker #Security #AI
   - Reddit: r/docker, r/selfhosted
   - Hacker News (Show HN)

3. **Blog post / tutorial** explicando el hardening

---

## 🔧 Troubleshooting

### Error: "remote origin already exists"
```bash
git remote remove origin
git remote add origin https://github.com/TU_USUARIO/ai-assistant-hardened.git
```

### Error: "Permission denied (publickey)"
Usa HTTPS en lugar de SSH, o configura SSH keys:
```bash
git remote set-url origin https://github.com/TU_USUARIO/ai-assistant-hardened.git
```

### Error: "refusing to merge unrelated histories"
```bash
git pull origin main --allow-unrelated-histories
```

---

## 📞 ¿Necesitas ayuda?

Si tienes problemas:
1. Verifica que Git está instalado: `git --version`
2. Verifica autenticación: `gh auth status` (si usas CLI)
3. Consulta GitHub Docs: https://docs.github.com/
