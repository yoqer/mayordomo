# ReadmeUse — Guía de despliegue local endurecido (producción local)

Este proyecto está configurado para **máxima seguridad en despliegue local**, con endurecimiento tipo producción.

---

## 🔒 Características de seguridad

- ✅ **Solo localhost** (127.0.0.1:8501) — no expuesto a la LAN por defecto
- ✅ **Usuario no-root** (uid 10001)
- ✅ **Filesystem read-only** + tmpfs para escritura temporal
- ✅ **Secrets externos** (no en variables de entorno)
- ✅ **Límites de recursos** (2GB RAM, 2 CPUs)
- ✅ **Logging con rotación** (10MB x 3 archivos)
- ✅ **Capabilities drop ALL** + no-new-privileges
- ✅ **Healthcheck funcional**
- ✅ **Restart policy** (unless-stopped)

---

## 📋 Requisitos previos

1. **Docker Desktop** actualizado con Docker Model Runner habilitado
   - [Descarga Docker Desktop](https://www.docker.com/)
   - [Habilitar Model Runner](https://dockr.ly/4nT2saM)

2. **Versiones seguras** (recomendado):
   - Docker Compose **v2.40.2+** (mitiga CVE-2025-62725)
   - Docker Desktop **v4.44.3+** (mitiga CVE-2025-9074)

Verificar versiones:
```bash
docker --version
docker compose version
```

---

## 🚀 Instalación rápida (3 pasos)

### 1) Configurar variables de entorno

Copia el archivo de ejemplo:
```bash
cp .env.example .env
```

Edita `.env` si quieres cambiar modelos/URLs (opcional).

### 2) Configurar API keys (solo si usas modelos remotos)

Edita los archivos en `secrets/` y coloca tus claves:
- `secrets/openrouter_api_key.txt` → tu clave de OpenRouter
- `secrets/remote_api_key.txt` → clave genérica para otro proveedor
- `secrets/grok_api_key.txt` → clave de Grok/xAI

**Importante:** Deja los archivos vacíos si solo usas modelo local.

### 3) Levantar el servicio

```bash
docker compose up --build
```

Abrir en navegador:
- **http://localhost:8501**

---

## 🛠️ Modos de operación

### Modo SEGURO (default, recomendado)
Sin bind mount, sin acceso desde LAN, máxima protección:
```bash
docker compose up --build
```

### Modo DEV (desarrollo)
Con bind mount del código, expuesto a LAN (0.0.0.0):
```bash
docker compose --profile dev -f docker-compose.yaml -f docker-compose.dev.yaml up --build
```

---

## 🔍 Verificación

### Healthcheck
```bash
curl http://localhost:8501/?healthz=1
# Respuesta esperada: ok
```

### Ver logs
```bash
docker compose logs -f ai-app
```

### Estado de contenedores
```bash
docker compose ps
```

---

## 🛑 Detener el servicio

```bash
docker compose down
```

---

## ⚙️ Personalización

### Cambiar modelo local
Edita `.env`:
```bash
LOCAL_MODEL_NAME=ai/gemma3
```

### Cambiar proveedor remoto
Edita `.env`:
```bash
REMOTE_BASE_URL=https://api.tu-proveedor.com/v1
REMOTE_MODEL_NAME=tu-modelo
```

Y pon la API key en el archivo correspondiente de `secrets/`.

### Exponer a la LAN (NO recomendado)
Si necesitas acceso desde otros dispositivos en tu red local, edita `docker-compose.yaml`:
```yaml
ports:
  - "8501:8501"  # cambiar de 127.0.0.1:8501:8501
```

**⚠️ Advertencia:** Esto expone la aplicación a toda tu red local.

---

## 🐛 Diagnóstico de problemas

### El contenedor está "unhealthy"
- Espera 30-60 segundos (start_period)
- Verifica logs: `docker compose logs ai-app`
- Verifica que wget esté instalado (ya incluido en Dockerfile)

### No se conecta al modelo local
- Verifica que Docker Model Runner esté habilitado en Docker Desktop
- Verifica `LOCAL_BASE_URL` en `.env`

### Error "falta API key"
- Si usas "Think harder" (modelo remoto), necesitas configurar `secrets/*.txt`
- Si solo usas local, no marques "Think harder"

### Puerto 8501 ya en uso
```bash
# Linux/macOS
lsof -i :8501

# Windows
netstat -ano | findstr :8501
```

---

## 📦 Estructura del proyecto

```
.
├── docker-compose.yaml          # Compose seguro (default)
├── docker-compose.dev.yaml      # Override para desarrollo
├── Dockerfile                   # Imagen no-root + wget
├── app.py                       # Aplicación Streamlit
├── requirements.txt             # Dependencias Python
├── .env.example                 # Plantilla de variables
├── .streamlit/
│   └── config.toml             # Config de Streamlit
├── secrets/
│   ├── openrouter_api_key.txt  # API key OpenRouter
│   ├── remote_api_key.txt      # API key genérica
│   └── grok_api_key.txt        # API key Grok
├── ReadmeUse.md                # Este archivo
├── ReadmeREPO.md               # Documentación técnica
├── SECURITY_CHANGES.md         # Cambios de seguridad
└── model_selector.html         # Selector de modelos (opcional)
```

---

## 🔗 Enlaces útiles

- [Docker Desktop](https://www.docker.com/)
- [Docker Model Runner](https://dockr.ly/4nT2saM)
- [Docker Security Announcements](https://docs.docker.com/security/security-announcements/)
- [OpenRouter](https://openrouter.ai/)
- [Streamlit](https://streamlit.io/)
- [LangChain](https://python.langchain.com/)

---

## 📝 Notas finales

- Este setup está optimizado para **uso local seguro**
- Para producción en servidor público, considera añadir:
  - Reverse proxy con TLS (Caddy/Nginx)
  - Autenticación (OAuth/Basic Auth)
  - Rate limiting
  - Firewall rules
  - Monitoring (Prometheus/Grafana)

- Los secrets nunca deben comitearse a Git
- El archivo `.env` tampoco debe comitearse (usa `.env.example`)
